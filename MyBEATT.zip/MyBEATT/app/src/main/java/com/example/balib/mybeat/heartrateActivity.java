package com.example.balib.mybeat;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class heartrateActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heartrate);
    }
}
